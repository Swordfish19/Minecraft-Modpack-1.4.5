package ro.narc.liquiduu;

import net.minecraft.src.Item;

public class ItemGeneric extends Item {
    public ItemGeneric(int itemID) {
        super(itemID);
    }
}
