package ro.narc.liquiduu;

import net.minecraft.src.Item;

public class CommonProxy {
    public void init() { };
}
